<?php

$myFile = "../lorder/".$_POST["url"];
$fh = fopen($myFile, 'w') or die("can't open file");
$stringData = $_POST["data"];
//var_dump($stringData);die;
fwrite($fh, $stringData);
fclose($fh)
?>