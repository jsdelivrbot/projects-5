<?php 

	$this->load->view('includes/header_give');
	$this->load->view($main_content);
	$this->load->view('includes/footer_give');


?>