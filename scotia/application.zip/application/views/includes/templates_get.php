<?php 

	$this->load->view('includes/header_get');
	$this->load->view($main_content);
	$this->load->view('includes/footer_get');


?>